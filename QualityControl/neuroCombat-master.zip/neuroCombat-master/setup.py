from distutils.core import setup

setup(
    name='neuroCombat',
    version='0.1dev',
    packages=['neuroCombat',],
    author='Nicholas Cullen'
)